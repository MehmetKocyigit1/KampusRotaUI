using System.Diagnostics;
using System.Globalization;
using KampusRotaUI.Models;
using KampusRotaUI.Services;

namespace KampusRotaUI.Views;

public partial class RideDetailPage : ContentPage
{
    private readonly ApiServices _apiService = new();
    private readonly Yolculuk _ride;

    public RideDetailPage(Yolculuk ride)
    {
        InitializeComponent();
        _ride = ride;
        RenderRide();
    }

    private void RenderRide()
    {
        RouteLabel.Text = _ride.Rota;
        DateLabel.Text = _ride.TarihFormatli;
        PriceLabel.Text = _ride.UcretMetni;
        SeatLabel.Text = $"{_ride.BosKoltukSayisi} koltuk";
        WomenOnlyBadge.IsVisible = _ride.SadeceKadinlarMi;

        var driverName = _ride.Surucu?.TamAd?.Trim();
        DriverNameLabel.Text = string.IsNullOrWhiteSpace(driverName) ? "Sürücü bilgisi" : driverName;

        var rating = _ride.Surucu?.OrtalamaPuan ?? 5.0;
        DriverRatingLabel.Text = rating.ToString("0.0", CultureInfo.InvariantCulture);
        DriverStarsLabel.Text = BuildStars(rating);

        var email = _ride.Surucu?.Email;
        var phone = _ride.Surucu?.TelefonNumarasi;
        DriverEmailLabel.Text = string.IsNullOrWhiteSpace(email) ? "E-posta: belirtilmemiş" : $"E-posta: {email}";
        DriverPhoneLabel.Text = string.IsNullOrWhiteSpace(phone) ? "Telefon: belirtilmemiş" : $"Telefon: {phone}";

        DescriptionBlock.IsVisible = !string.IsNullOrWhiteSpace(_ride.Aciklama);
        DescriptionLabel.Text = _ride.Aciklama;

        JoinButton.IsEnabled = _ride.BosKoltukSayisi > 0 && _ride.KalkisZamani > DateTime.Now;
        JoinButton.Text = JoinButton.IsEnabled ? "Katılma talebi gönder" : "Bu ilan uygun değil";
    }

    private async void OnBackClicked(object sender, EventArgs e)
    {
        await Navigation.PopAsync();
    }

    private async void OnJoinClicked(object sender, EventArgs e)
    {
        if (_ride.BosKoltukSayisi <= 0)
        {
            await DisplayAlert("Koltuk Yok", "Bu ilanda boş koltuk kalmamış.", "Tamam");
            return;
        }

        var currentUserId = GetCurrentUserId();
        if (currentUserId == 0)
        {
            await DisplayAlert("Oturum", "Katılmak için tekrar giriş yapmalısın.", "Tamam");
            return;
        }

        if (_ride.SurucuId == currentUserId)
        {
            await DisplayAlert("Bilgi", "Kendi ilanına katılma talebi gönderemezsin.", "Tamam");
            return;
        }

        var confirm = await DisplayAlert(
            "Katılma Talebi",
            $"{_ride.Rota} yolculuğu için sürücüye talep göndermek istiyor musun?",
            "Gönder",
            "Vazgeç");

        if (!confirm)
        {
            return;
        }

        var updatedRide = new Yolculuk
        {
            Id = _ride.Id,
            SurucuId = _ride.SurucuId,
            KalkisNoktasi = _ride.KalkisNoktasi,
            VarisNoktasi = _ride.VarisNoktasi,
            KalkisZamani = _ride.KalkisZamani,
            BosKoltukSayisi = Math.Max(0, _ride.BosKoltukSayisi - 1),
            KisiBasiUcret = _ride.KisiBasiUcret,
            Aciklama = _ride.Aciklama,
            SadeceKadinlarMi = _ride.SadeceKadinlarMi,
            AktifMi = _ride.AktifMi,
            SilindiMi = _ride.SilindiMi
        };

        try
        {
            var success = await _apiService.YolculukGuncelleAsync(_ride.Id, updatedRide, currentUserId);
            if (!success)
            {
                await DisplayAlert("Hata", "Talep gönderilemedi. Lütfen tekrar dene.", "Tamam");
                return;
            }

            _ride.BosKoltukSayisi = updatedRide.BosKoltukSayisi;
            RenderRide();

            await DisplayAlert(
                "Talep Gönderildi",
                "Koltuk talebin kaydedildi. Sürücüyle telefon veya e-posta üzerinden iletişime geçebilirsin.",
                "Tamam");
        }
        catch (Exception ex)
        {
            Debug.WriteLine($"Katılma talebi hatası: {ex.Message}");
            await DisplayAlert("Hata", "Talep gönderilirken bir sorun oluştu.", "Tamam");
        }
    }

    private async void OnCallClicked(object sender, EventArgs e)
    {
        var phone = _ride.Surucu?.TelefonNumarasi;
        if (string.IsNullOrWhiteSpace(phone))
        {
            await DisplayAlert("Telefon", "Sürücü telefon numarası paylaşmamış.", "Tamam");
            return;
        }

        await Launcher.Default.OpenAsync($"tel:{Uri.EscapeDataString(phone)}");
    }

    private async void OnEmailClicked(object sender, EventArgs e)
    {
        var email = _ride.Surucu?.Email;
        if (string.IsNullOrWhiteSpace(email))
        {
            await DisplayAlert("E-posta", "Sürücü e-posta adresi paylaşmamış.", "Tamam");
            return;
        }

        var subject = Uri.EscapeDataString($"KampüsRota yolculuk talebi: {_ride.Rota}");
        var body = Uri.EscapeDataString("Merhaba, ilandaki yolculuğa katılmak istiyorum. Uygunsa detayları konuşabilir miyiz?");
        await Launcher.Default.OpenAsync($"mailto:{email}?subject={subject}&body={body}");
    }

    private static int GetCurrentUserId()
    {
        var userIdText = Preferences.Default.Get("UserId", "0");
        return int.TryParse(userIdText, out var userId) ? userId : 0;
    }

    private static string BuildStars(double rating)
    {
        var fullStars = Math.Clamp((int)Math.Round(rating, MidpointRounding.AwayFromZero), 0, 5);
        return new string('★', fullStars) + new string('☆', 5 - fullStars);
    }
}
